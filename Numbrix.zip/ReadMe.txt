This is the Read Me file for Numbrix program by Hohyun Jeon.
The program has a main menu with three main functions and a exit option.

To use the program, load into a java IDE as a project and execute and follow through on the command prompt.

the main focus will be on function #2: the AI solver.
to load files, they must be in the format described. Examples can be seen in the zip file as txt files.
When typing in a directory, the .txt must also be written in.

So far the program is able to solve intermediate problems on http://www.parade.com/168193/marilynvossavant/numbrix-9-november-26-6/
but has problems with larger and more difficult problems. Given more time i would have been able to make the program better.

There may be special cases where you need to expand the window. Look in your system preferences as exporting data is not yet implemented.